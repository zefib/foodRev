-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: May 24, 2017 at 01:42 PM
-- Server version: 10.1.16-MariaDB
-- PHP Version: 7.0.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `foodreview`
--

-- --------------------------------------------------------

--
-- Table structure for table `cr_admin`
--

CREATE TABLE `cr_admin` (
  `cr_adminID` int(11) NOT NULL,
  `cr_adminUsername` varchar(50) NOT NULL,
  `cr_adminPassword` varchar(200) NOT NULL,
  `cr_adminEmail` varchar(100) NOT NULL,
  `cr_adminPhoto` varchar(200) NOT NULL,
  `cr_adminRegistered` datetime NOT NULL,
  `cr_adminDisplayName` varchar(100) NOT NULL,
  `cr_adminLevel` int(1) NOT NULL,
  `cr_adminAbout` varchar(255) NOT NULL,
  `cr_adminLastlogin` datetime NOT NULL,
  `cr_adminFacebook` varchar(200) NOT NULL,
  `cr_adminGoogleplus` varchar(200) NOT NULL,
  `cr_adminTwitter` varchar(200) NOT NULL,
  `cr_adminToken` varchar(200) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cr_admin`
--

INSERT INTO `cr_admin` (`cr_adminID`, `cr_adminUsername`, `cr_adminPassword`, `cr_adminEmail`, `cr_adminPhoto`, `cr_adminRegistered`, `cr_adminDisplayName`, `cr_adminLevel`, `cr_adminAbout`, `cr_adminLastlogin`, `cr_adminFacebook`, `cr_adminGoogleplus`, `cr_adminTwitter`, `cr_adminToken`) VALUES
(1, 'administrator', '$2y$11$dc1e4a84d7815b6dae004OMXIzLPHlbtSRSla6E5hsNXxwwvqeIMS', 'example@mail.com', 'df9501a11c224052ea51e9b76bfce666.jpg', '2017-03-13 10:52:21', 'Adi Santos', 1, '', '2017-05-24 19:18:19', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `cr_article`
--

CREATE TABLE `cr_article` (
  `cr_ID` int(11) NOT NULL,
  `cr_title` varchar(200) NOT NULL,
  `cr_desc` text NOT NULL,
  `cr_image` varchar(200) NOT NULL,
  `cr_date` datetime NOT NULL,
  `cr_adminID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_article`
--

INSERT INTO `cr_article` (`cr_ID`, `cr_title`, `cr_desc`, `cr_image`, `cr_date`, `cr_adminID`) VALUES
(2, 'About Us', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Etiam vitae felis vitae quam elementum porta et sit amet ligula. Nullam elementum volutpat enim vel tempor. Nulla consequat, lacus et malesuada vehicula, ex lectus dictum quam, sit amet blandit urna magna a ante. Fusce a porta nisi, a luctus elit. Aenean vel ipsum pretium, porttitor quam sed, pretium risus. Cras gravida venenatis ipsum, a facilisis ante. In consequat ipsum vehicula enim luctus, in ultrices nibh hendrerit. Sed pharetra sapien turpis. Donec varius bibendum hendrerit. Nulla consequat, lacus et malesuada vehicula, ex lectus dictum quam, sit amet blandit urna magna a ante. Fusce a porta nisi, a luctus elit.', 'bb8fd64138f31ea6e55a7f7935c4322e.jpg', '2017-04-16 19:28:08', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cr_foodies`
--

CREATE TABLE `cr_foodies` (
  `cr_loginID` int(11) NOT NULL,
  `cr_name` varchar(200) NOT NULL,
  `cr_email` varchar(200) NOT NULL,
  `cr_password` varchar(200) NOT NULL,
  `cr_website` varchar(200) NOT NULL,
  `cr_city` varchar(200) NOT NULL,
  `cr_phone` varchar(100) NOT NULL,
  `cr_photo` varchar(255) NOT NULL,
  `cr_about` text NOT NULL,
  `cr_registered` datetime NOT NULL,
  `cr_lastLogin` datetime NOT NULL,
  `cr_token` varchar(255) NOT NULL,
  `cr_verifyaccount` int(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_foodies`
--

INSERT INTO `cr_foodies` (`cr_loginID`, `cr_name`, `cr_email`, `cr_password`, `cr_website`, `cr_city`, `cr_phone`, `cr_photo`, `cr_about`, `cr_registered`, `cr_lastLogin`, `cr_token`, `cr_verifyaccount`) VALUES
(1, 'Susan', 'suan1234@yahoo.com', '$2y$11$5a41340d4e8a009dc0bd6OONG/P7y8QR9PeRpcpQwMpC3HK7XmvNS', '', 'Aceh Jaya', '0815678899990', 'b77f09341533e7260be439cc1c4daaa3.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae blandit nisl. Quisque ut risus mattis, finibus dolor posuere, blandit ligula. Nam nulla dui, molestie at velit at, imperdiet elementum est. Nulla vitae iaculis massa. Donec pellentesque sapien eget laoreet posuere. Morbi rutrum ornare est in eleifend. Nullam ac tortor enim.', '2017-04-16 22:12:02', '2017-04-16 22:12:02', '', 0),
(2, 'Santos', 'santosguterres@yahoo.com', '$2y$11$0bb2cb8a64ef31239ef48uyUL2UyMOE01OZTbdBkO5USL6epepQ4u', 'deddyresto.com', 'Denpasar', '082987654321', 'fed59bb8f6d8d65243ef1ed6fe3c08b5.jpg', 'Nice Looking and good person', '2017-04-25 05:31:21', '2017-05-14 11:42:44', '', 0),
(3, 'Sidi', 'sidi@gmail.com', '$2y$11$80c618e7db82495ddf2f1uQWwd03PwORz6pab8cvHKFPhr8hR1OlW', '', '', '', '', '', '2017-05-04 08:37:43', '2017-05-10 06:22:28', '', 0),
(4, 'Agus', 'agus@mail.com', '$2y$11$18d8c7a172389e2cc6d39u9Mk8S1ejbcf/Z0Y.tOAVRiSFA3kp/hS', '', '', '', '', '', '2017-05-09 12:19:48', '2017-05-09 12:19:48', '', 0),
(5, 'Ester', 'ester@mial.com', '$2y$11$d1bcb1827945af1413c3buhY7LA9bRnH8SuJwN3T8G28z6RFf2n/y', '', '', '', '', '', '2017-05-09 12:21:23', '2017-05-09 12:21:23', '', 0),
(11, 'Deddyguterres', 'deddy@yahoo.com', '$2y$11$13b13a88a1ac6aa9d93aeum7cB1V5mzFUPRamFo/mc7B1YZriQxCa', '', '', '', '', '', '2017-05-10 06:26:32', '2017-05-10 06:26:32', '', 0),
(16, 'Batman', 'bat@gmail.com', '$2y$11$308427c62c208dcd7db95O.edZrxz5FDtI8nU7oWS5ukUi9qZso.C', 'batsy.co.id', 'Denpasar', '082987654321', '3740321484bde8ff41db0736607e2b39.jpg', 'famous person', '2017-05-14 13:36:57', '2017-05-17 12:05:48', '', 0),
(19, 'Adisantos', 'adisantos@gmail.com', '$2y$11$b83061641fc7d24172833Od.B4BkuGiIyeUMw1rfRjLw84Of7xaSC', 'foodrev.com', 'Denpasar', '082146753154', '373e6b4907482f512d89bfbdb366aa86.jpg', 'fun person with good personality', '2017-05-20 09:55:03', '2017-05-22 11:37:19', '', 0),
(21, 'Zefibulkiah', 'zefi@gmail.com', '$2y$11$b92e8fe42dc214b53056du3QfWft6L22o93rYp6NJwJ2ixFOu6zJ2', 'foodrev.com', 'Denpasar', '082124789908', '41fc06e7c3f964a9fa16800285b985bb.jpg', 'Good Person', '2017-05-24 11:03:29', '2017-05-24 11:03:29', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `cr_history`
--

CREATE TABLE `cr_history` (
  `cr_historyID` int(11) NOT NULL,
  `cr_historyTitle` varchar(200) NOT NULL,
  `cr_historyDetail` text NOT NULL,
  `cr_historyDateTime` datetime NOT NULL,
  `cr_adminID` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cr_history`
--

INSERT INTO `cr_history` (`cr_historyID`, `cr_historyTitle`, `cr_historyDetail`, `cr_historyDateTime`, `cr_adminID`) VALUES
(1, 'Add New Feature', ' add new feature data.', '2017-03-27 23:22:45', 1),
(2, 'Add New Feature', ' add new feature data.', '2017-03-27 23:24:27', 1),
(3, 'Add New Feature', ' add new feature data.', '2017-03-27 23:30:11', 1),
(4, 'Add New Feature', ' add new feature data.', '2017-03-27 23:38:25', 1),
(5, 'Add New Feature', ' add new feature data.', '2017-03-27 23:41:07', 1),
(6, 'Add New Feature', ' add new feature data.', '2017-03-27 23:43:20', 1),
(7, 'Add New Feature', ' add new feature data.', '2017-03-27 23:51:19', 1),
(8, 'Delete Feature', ' delete  in feature section.', '2017-03-29 16:58:01', 1),
(9, 'Delete Feature', ' delete  in feature section.', '2017-03-29 16:59:56', 1),
(10, 'Delete Feature', ' delete Breakfast in feature section.', '2017-03-29 17:03:44', 1),
(11, 'Delete Feature', ' delete Hahaha in feature section.', '2017-03-29 17:04:30', 1),
(12, 'Delete Feature', ' delete Bababa in feature section.', '2017-03-29 17:06:31', 1),
(13, 'Edit Feature', ' edit feature in feature section.', '2017-03-29 17:28:58', 1),
(14, 'Add New Feature', ' add new feature data.', '2017-03-29 17:31:18', 1),
(15, 'Add New Feature', ' add new feature data.', '2017-03-29 17:31:52', 1),
(16, 'Add New Feature', ' add new feature data.', '2017-03-29 17:32:07', 1),
(17, 'Add New Feature', ' add new feature data.', '2017-03-29 17:32:23', 1),
(18, 'Add New Cuisine', ' add new cuisine data.', '2017-03-29 18:12:03', 1),
(19, 'Add New Cuisine', ' add new cuisine data.', '2017-03-29 18:13:07', 1),
(20, 'Add New Cuisine', ' add new cuisine data.', '2017-03-29 18:16:08', 1),
(21, 'Edit Cuisine', ' edit cuisine in cuisines section.', '2017-03-29 18:32:52', 1),
(22, 'Edit Cuisine', ' edit cuisine in cuisines section.', '2017-03-29 18:34:04', 1),
(23, 'Edit Cuisine', ' edit cuisine in cuisines section.', '2017-03-29 18:34:25', 1),
(24, 'Add New Cuisine', ' add new cuisine data.', '2017-03-29 18:34:39', 1),
(25, 'Add New Cuisine', ' add new cuisine data.', '2017-03-29 18:37:38', 1),
(26, 'Delete Cuisine', ' delete  in cuisines section.', '2017-03-29 18:45:17', 1),
(27, 'Add New Type', ' add new type data.', '2017-03-29 18:57:50', 1),
(28, 'Add New Type', ' add new type data.', '2017-03-29 19:02:44', 1),
(29, 'Add New Type', ' add new type data.', '2017-03-29 19:02:55', 1),
(30, 'Edit Type', ' edit type in type section.', '2017-03-29 19:07:01', 1),
(31, 'Edit Type', ' edit type in type section.', '2017-03-30 01:11:09', 1),
(32, 'Edit Type', ' edit type in type section.', '2017-03-30 01:11:51', 1),
(33, 'Edit Type', ' edit type in type section.', '2017-03-30 01:12:16', 1),
(34, 'Edit Type', ' edit type in type section.', '2017-03-30 01:12:42', 1),
(35, 'Add New Type', ' add new type data.', '2017-03-30 01:12:53', 1),
(36, 'Delete Type', ' delete  in cuisines section.', '2017-03-30 01:17:24', 1),
(37, 'Add New Category', ' add new category data.', '2017-03-30 03:09:09', 1),
(38, 'Add New Media', ' upload b464af902f2737534729933d7ca63553.jpg as a new media.', '2017-03-30 03:15:17', 1),
(39, 'Add New Category', ' add new category data.', '2017-03-30 03:15:24', 1),
(40, 'Edit Category', ' edit category in category section.', '2017-03-30 09:19:13', 1),
(41, 'Add New Media', ' upload 4a827a65f3bef1cefa784c6c262bddfd.jpg as a new media.', '2017-03-30 09:19:51', 1),
(42, 'Edit Category', ' edit category in category section.', '2017-03-30 09:19:55', 1),
(43, 'Add New Category', ' add new category data.', '2017-03-30 09:38:47', 1),
(44, 'Add New Media', ' upload 9c54bce8ce81d0f1eb6ff8661c9db4b5.jpg as a new media.', '2017-03-30 09:39:40', 1),
(45, 'Edit Category', ' edit category in category section.', '2017-03-30 09:39:43', 1),
(46, 'Add New Media', ' upload c31c2345a82205a9e600401005d8b752.jpg as a new media.', '2017-04-10 20:29:16', 9),
(47, 'Add New Media', ' upload 4b259757c8509ec04220283de5c23292.jpg as a new media.', '2017-04-10 21:03:13', 9),
(48, 'Add New Media', ' upload 032783a27c56f44a0d820cc8e4015c68.jpg as a new media.', '2017-04-10 21:12:21', 1),
(49, 'Add New Media', ' upload 11fbec840917da56d8ec893942923679.jpg as a new media.', '2017-04-10 21:15:50', 9),
(50, 'Add New Media', ' upload 700902d8c06fefa5c4a784121859e9b5.jpg as a new media.', '2017-04-10 21:23:27', 9),
(51, 'Add New Media', ' upload ba6cf450bda9605dbc51c60c8ece416a.jpg as a new media.', '2017-04-10 21:32:04', 9),
(52, 'Add New Media', ' upload 54d859c89928da5fcad40229456c887b.jpg as a new media.', '2017-04-10 21:40:37', 9),
(53, 'Add New Media', ' upload 306635c3d4e235f691d45fc23aec27a8.jpg as a new media.', '2017-04-10 21:48:39', 9),
(54, 'Add New Media', ' upload 09d04054b833d65e7c07e4fee75ddb17.jpg as a new media.', '2017-04-10 21:54:15', 9),
(55, 'Add New Media', ' upload 3ab3708ca4ddab7a77cfab4475218446.jpg as a new media.', '2017-04-10 21:56:11', 9),
(56, 'Add New Media', ' upload 813fa15e03f3e2dd71e793c627f7c592.jpg as a new media.', '2017-04-10 22:00:58', 9),
(57, 'Add New Media', ' upload aa97426f7e21485ecc59acdd11f974d3.jpg as a new media.', '2017-04-11 08:18:05', 10),
(58, 'Add New Media', ' upload 66bec89f7d6ca425fdd59edc74d21014.jpg as a new media.', '2017-04-11 08:47:54', 12),
(59, 'Add New Media', ' upload 728d46f3942d5d2aa88be4f889b924c7.jpg as a new media.', '2017-04-11 08:51:33', 12),
(60, 'Add New Media', ' upload 565de082e23e5751443ada135ccd6f40.jpg as a new media.', '2017-04-11 08:54:13', 12),
(61, 'Add New Media', ' upload 05ddc2c81d5426e84cb7f6562ecf7bf1.jpg as a new media.', '2017-04-11 08:54:30', 12),
(62, 'Add New Media', ' upload 18aebcdbaba622ea6683c8774ea9a12c.jpg as a new media.', '2017-04-11 08:57:38', 12),
(63, 'Add New Media', ' upload 573dc56d0e5e6a5ba645adb0b6f26129.jpg as a new media.', '2017-04-11 09:08:19', 12),
(64, 'Add New Media', ' upload 49fa580bef95c0f6e8e166939c111966.jpg as a new media.', '2017-04-11 09:25:45', 12),
(65, 'Add New Media', ' upload eb4e91dcfc0a1399ad99c940c1f650a4.jpg as a new media.', '2017-04-14 07:33:19', 1),
(66, 'Add New Media', ' upload ded4f5d44f9b086dfdec63153a78f19f.jpg as a new media.', '2017-04-14 07:40:03', 1),
(67, 'Add New Media', ' upload b368b79a2850756aecf805b30fca1920.jpg as a new media.', '2017-04-14 07:49:01', 1),
(68, 'Add New Media', ' upload 35db64518ba7016f5f824a75c8df2b8c.jpg as a new media.', '2017-04-15 06:52:40', 1),
(69, 'Add New Media', ' upload c6f1900f0a8d9975beed6948835071d9.jpg as a new media.', '2017-04-15 06:54:39', 1),
(70, 'Add New Media', ' upload 6700b01d890331b890d9b54f93e1ad24.jpg as a new media.', '2017-04-15 06:57:32', 1),
(71, 'Add New Media', ' upload 0c87a7b7355e24a827e1c68a7da504e9.jpg as a new media.', '2017-04-15 07:02:34', 1),
(72, 'Add New Media', ' upload 340912857e778c9c2e633a4481069f29.jpg as a new media.', '2017-04-15 07:03:30', 1),
(73, 'Add New Media', ' upload a61d1bab885f37db8f5e536dd79c1fb4.jpg as a new media.', '2017-04-15 08:43:56', 1),
(74, 'Add New Media', ' upload e612ab764af12795f601040c671ec39e.jpg as a new media.', '2017-04-15 08:51:06', 1),
(75, 'Add New Media', ' upload f70f93263c77b358fdc78500450321f7.jpg as a new media.', '2017-04-15 08:52:59', 1),
(76, 'Add New Slider Image', ' add new slider image in slider image section', '2017-04-15 14:53:35', 1),
(77, 'Add New Media', ' upload b85c00f2dfde40f432100f6484371adc.jpg as a new media.', '2017-04-15 08:54:01', 1),
(78, 'Add New Slider Image', ' add new slider image in slider image section', '2017-04-15 14:54:21', 1),
(79, 'Add New Media', ' upload 9bbe3349b7a58b7f39b684372e67a0bd.jpg as a new media.', '2017-04-15 08:54:45', 1),
(80, 'Add New Slider Image', ' add new slider image in slider image section', '2017-04-15 14:55:03', 1),
(81, 'Add New Media', ' upload 279cd9e3da1efc979ac70ce99f1ab976.jpg as a new media.', '2017-04-15 09:06:34', 1),
(82, 'Add New Media', ' upload c7381cd1c4b708d29712312864815e44.jpg as a new media.', '2017-04-15 09:57:27', 1),
(83, 'Add New Media', ' upload 10c515e372cce467c92e3eb620093cb4.jpg as a new media.', '2017-04-15 10:10:15', 1),
(84, 'Add New Media', ' upload 81c6cc9507134aeefa9381c435d69ec1.jpg as a new media.', '2017-04-15 10:11:57', 1),
(85, 'Add New Media', ' upload 8453d7f885c15a4edfc332c516bd8fe1.jpg as a new media.', '2017-04-15 10:13:02', 1),
(86, 'Add New Media', ' upload fb1728faf9e55e12ecde9a6dc6e6e630.jpg as a new media.', '2017-04-15 10:15:33', 1),
(87, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-04-15 16:15:37', 1),
(88, 'Add New Media', ' upload 83830278cd6eb937f56fa75b57633e3c.jpg as a new media.', '2017-04-15 10:18:09', 1),
(89, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-04-15 16:18:19', 1),
(90, 'Add New Media', ' upload 62f87aa51b8758fcc8fe837ab33fb002.jpg as a new media.', '2017-04-15 11:46:37', 15),
(91, 'Add New Media', ' upload 4619fc3e3528826cb41e6771d174549d.jpg as a new media.', '2017-04-15 11:49:10', 15),
(92, 'Add New Media', ' upload 0f061c2aed1ba22b937b1001b85132ea.jpg as a new media.', '2017-04-15 11:56:05', 15),
(93, 'Add New Media', ' upload 7eca01777350f7043df3a851d954a73a.jpg as a new media.', '2017-04-15 12:42:24', 10),
(94, 'Add New Media', ' upload 8beb2bb1e9f4883babc2d6d145febe63.jpg as a new media.', '2017-04-15 12:55:06', 10),
(95, 'Add New Media', ' upload aa4c020f4378ddf2f81446adfd97e137.jpg as a new media.', '2017-04-15 12:57:02', 10),
(96, 'Add New Media', ' upload 0c8875818e0b01b682a1e6f4bdb5fea8.jpg as a new media.', '2017-04-15 13:01:08', 10),
(97, 'Add New Media', ' upload c6944ce1f543138a21c216e066ec2e7f.jpg as a new media.', '2017-04-15 13:15:36', 10),
(98, 'Add New Media', ' upload a64f7755c1f59dec6942555dce1e8fb4.jpg as a new media.', '2017-04-15 13:26:10', 10),
(99, 'Add New Media', ' upload 3d57b7a32c2a1bfdf567037e324ef298.jpg as a new media.', '2017-04-15 13:28:09', 10),
(100, 'Add New Media', ' upload ebf367bda501a7b0ff18c00e7f3535b9.jpg as a new media.', '2017-04-15 13:29:19', 10),
(101, 'Add New Media', ' upload b397e9842f22f6e85583ea20f563f5db.jpg as a new media.', '2017-04-16 18:56:38', 1),
(102, 'Add New Media', ' upload 31879c30378ff5fe5064913f892e6f8b.jpg as a new media.', '2017-04-16 19:01:50', 1),
(103, 'Add New Media', ' upload 85dc6daca988978385ed2245839b236a.jpg as a new media.', '2017-04-16 19:03:18', 1),
(104, 'Add New article', ' add new article data.', '2017-04-16 19:03:20', 1),
(105, 'Add New Media', ' upload e90b30c6f3eb4987fde79600dea4a3b0.jpg as a new media.', '2017-04-16 19:09:42', 1),
(106, 'Add New Media', ' upload 8be07a5f025345478ca632d1d7c924fc.jpg as a new media.', '2017-04-16 19:17:24', 1),
(107, 'Edit article', ' edit article in article section.', '2017-04-16 19:17:28', 1),
(108, 'Add New Media', ' upload d158e14d7aea1a7d7bc2f6a13bbed885.jpg as a new media.', '2017-04-16 19:18:11', 1),
(109, 'Edit article', ' edit article in article section.', '2017-04-16 19:18:14', 1),
(110, 'Delete article', ' delete  in article section.', '2017-04-16 19:24:55', 1),
(111, 'Delete article', ' delete  in article section.', '2017-04-16 19:27:16', 1),
(112, 'Add New Media', ' upload bb8fd64138f31ea6e55a7f7935c4322e.jpg as a new media.', '2017-04-16 19:28:05', 1),
(113, 'Add New article', ' add new article data.', '2017-04-16 19:28:08', 1),
(114, 'Add New Media', ' upload 2f0e509234da16af72f8b6f7b2fd3f12.jpg as a new media.', '2017-04-16 21:48:08', 1),
(115, 'Add New Media', ' upload f0f18515261ebead8bf746d17ddbc613.jpg as a new media.', '2017-04-16 21:51:06', 1),
(116, 'Add New Media', ' upload 7b4f4e5abbccbfa4c0374a302881aac2.jpg as a new media.', '2017-04-16 21:52:38', 1),
(117, 'Add New Media', ' upload 4ded15b8cc41b0be532b531d4f85ffdf.jpg as a new media.', '2017-04-16 21:54:02', 1),
(118, 'Add New Media', ' upload 46a9bdbb7294dd091e26bd40c0e45265.jpg as a new media.', '2017-04-16 21:58:07', 2),
(119, 'Add New Media', ' upload 7d4de6f5ae06acdc3f25ed907efb00c7.jpg as a new media.', '2017-04-16 22:00:14', 2),
(120, 'Add New Media', ' upload 8d584b5656218677423898764c4dd913.jpg as a new media.', '2017-04-16 22:01:39', 2),
(121, 'Add New Media', ' upload 72c9e09daf792498e4aba989a3a32fbc.jpg as a new media.', '2017-04-16 22:05:13', 3),
(122, 'Add New Media', ' upload dc37ef064e7308dc6623abe0651fa7d6.jpg as a new media.', '2017-04-16 22:10:07', 4),
(123, 'Add New Media', ' upload b77f09341533e7260be439cc1c4daaa3.jpg as a new media.', '2017-04-16 22:12:51', 1),
(124, 'Add New Media', ' upload 5acb59662d6abf5ee214afdc529605ff.jpg as a new media.', '2017-04-18 17:38:00', 1),
(125, 'Add Administrator', ' add Baba Moli as an .', '2017-04-18 23:41:02', 1),
(126, 'Add New Media', ' upload 7cce69b588d25a90c6f9fb156fbc683e.jpg as a new media.', '2017-04-18 17:54:30', 1),
(127, 'Add New Media', ' upload 5658a12a45b0b150df6374cad2dbc0b3.jpg as a new media.', '2017-04-18 18:14:38', 1),
(128, 'Edit Administrator', ' edit Arsitek''s profile data.', '2017-04-19 00:14:45', 1),
(129, 'Delete User', ' delete Baba Moli from users data.', '2017-04-19 00:19:32', 1),
(130, 'Add New Media', ' upload 9bfc05b168eb9942a6aa77e0778b7936.jpg as a new media.', '2017-04-18 18:23:12', 1),
(131, 'Add Administrator', ' add Roberto as an .', '2017-04-19 00:23:15', 1),
(132, 'Delete User', ' delete Roberto from users data.', '2017-04-19 00:25:09', 1),
(133, 'Edit Setting Value', ' edit facebook setting value to facebook.com.', '2017-04-19 01:33:21', 1),
(134, 'Edit Setting Value', ' edit twitter setting value to twitter.com.', '2017-04-19 01:33:38', 1),
(135, 'Edit Setting Value', ' edit google plus setting value to google.com.', '2017-04-19 01:34:30', 1),
(136, 'Add New Media', ' upload 356688a8aa1ab8b4ade9606dd914abd5.jpg as a new media.', '2017-04-25 05:32:32', 2),
(137, 'Add New Media', ' upload af485780f12e8b4e7f77fe686b28ee3e.jpg as a new media.', '2017-05-02 11:29:06', 2),
(138, 'Edit Administrator', ' edit Zefi Bulkiah''s profile data.', '2017-05-02 17:37:30', 1),
(139, 'Add New Media', ' upload 2cf0cce0e17fd68d64a221aa5c9a9d02.jpg as a new media.', '2017-05-10 05:43:01', 7),
(140, 'Add New Media', ' upload c4ec6d47f78205aac2dc575f6522e67c.jpg as a new media.', '2017-05-10 05:52:37', 8),
(141, 'Add New Media', ' upload 4207b906fae5a9275aff92af47c8fec4.jpg as a new media.', '2017-05-10 10:50:19', 1),
(142, 'Edit Administrator', ' edit Zefi Bulkiah''s profile data.', '2017-05-10 16:50:27', 1),
(143, 'Edit Administrator', ' edit Adi Santos''s profile data.', '2017-05-10 16:51:07', 1),
(144, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-13 16:20:28', 1),
(145, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-13 16:20:43', 1),
(146, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-13 16:20:57', 1),
(147, 'Add New Media', ' upload 316fd6400b9ff33259109380e935dd70.jpg as a new media.', '2017-05-14 11:44:24', 2),
(148, 'Add New Media', ' upload fed59bb8f6d8d65243ef1ed6fe3c08b5.jpg as a new media.', '2017-05-14 11:45:21', 2),
(149, 'Add New Media', ' upload c9d3a2bc57e13d461e77180591c75762.jpg as a new media.', '2017-05-14 13:28:39', 15),
(150, 'Add New Media', ' upload 0c07ba6b017e9479a9506551edea9350.jpg as a new media.', '2017-05-14 13:37:36', 16),
(151, 'Add New Media', ' upload 5144d5296d35c3fa3a22987e6f65de35.jpg as a new media.', '2017-05-14 13:46:45', 10),
(152, 'Add New Media', ' upload 43bbd4e07931b2785601390fa3ebb241.jpg as a new media.', '2017-05-14 13:49:00', 10),
(153, 'Add New Media', ' upload 6e672a848985ec7ae5ef07763acb27ed.jpg as a new media.', '2017-05-14 13:59:19', 11),
(154, 'Add New Media', ' upload f273f27714b810a99d1f020874ec36ca.jpg as a new media.', '2017-05-14 13:59:51', 11),
(155, 'Add New Media', ' upload 42e804b78717fc394b1d84106c9256d7.jpg as a new media.', '2017-05-14 14:03:17', 11),
(156, 'Add New Media', ' upload 7e2c00ab11a4d01a0e77defb64005fa7.jpg as a new media.', '2017-05-14 14:08:43', 12),
(157, 'Add New Media', ' upload 423af05b3921b7de30b099e8c3c82e62.jpg as a new media.', '2017-05-14 14:09:07', 12),
(158, 'Delete Slider Image', ' delete one slider image in slider image section.', '2017-05-16 12:09:43', 1),
(159, 'Add New Media', ' upload df11d0a44cc60e8827b9771ef0b54bdb.jpg as a new media.', '2017-05-16 06:10:15', 1),
(160, 'Add New Slider Image', ' add new slider image in slider image section', '2017-05-16 12:10:22', 1),
(161, 'Delete Slider Image', ' delete one slider image in slider image section.', '2017-05-16 12:13:41', 1),
(162, 'Add New Media', ' upload 3dd6addfbc8cf98575f931f168e07b84.jpg as a new media.', '2017-05-16 06:14:02', 1),
(163, 'Add New Slider Image', ' add new slider image in slider image section', '2017-05-16 12:14:13', 1),
(164, 'Delete Slider Image', ' delete one slider image in slider image section.', '2017-05-16 12:14:30', 1),
(165, 'Add New Media', ' upload 0bfa1d7648d75b6d1c4bba74bad4c0c6.jpg as a new media.', '2017-05-16 06:14:44', 1),
(166, 'Add New Slider Image', ' add new slider image in slider image section', '2017-05-16 12:14:47', 1),
(167, 'Delete Slider Image', ' delete one slider image in slider image section.', '2017-05-16 12:15:54', 1),
(168, 'Add New Media', ' upload aac396a1f1e0bfb8946070284be5a50e.jpg as a new media.', '2017-05-16 06:23:45', 1),
(169, 'Add New Slider Image', ' add new slider image in slider image section', '2017-05-16 12:23:47', 1),
(170, 'Add New Media', ' upload 7e6003f2087f5521ad8a0801c84e920f.jpg as a new media.', '2017-05-16 08:23:04', 13),
(171, 'Add New Media', ' upload 9b2b5b4001f4bfb57dbf59d11c5f51f8.jpg as a new media.', '2017-05-16 08:26:50', 13),
(172, 'Add New Media', ' upload ae125369d6001c8b42c472a115015792.jpg as a new media.', '2017-05-16 08:36:00', 1),
(173, 'Add New Media', ' upload fa34a0807ff8f6dd879672a69f2a6395.jpg as a new media.', '2017-05-16 08:41:52', 1),
(174, 'Add New Media', ' upload 7ddec448acd976a13d423e5f37626ba3.jpg as a new media.', '2017-05-16 08:42:21', 1),
(175, 'Add New Media', ' upload 85473476ff515c792af24bcc7cea35d0.jpg as a new media.', '2017-05-16 08:46:14', 13),
(176, 'Add New Media', ' upload 5e1170007fb95b4a76d2464d0d5674a0.jpg as a new media.', '2017-05-16 08:48:08', 1),
(177, 'Add New Media', ' upload 612850d0d809bbee965a316ef48cac51.jpg as a new media.', '2017-05-16 08:51:16', 13),
(178, 'Add New Media', ' upload 40f6de9cf610c6e1792b0041827fc917.jpg as a new media.', '2017-05-16 08:52:58', 1),
(179, 'Add New Media', ' upload 9b0a86b82d1e21a431f3f3801c402571.jpg as a new media.', '2017-05-16 08:54:21', 13),
(180, 'Add New Media', ' upload c081dded033d4f5773dde4e77f87610d.jpg as a new media.', '2017-05-16 08:59:07', 13),
(181, 'Add New Media', ' upload befdc2f0ac215cece44dcf5382412d3b.jpg as a new media.', '2017-05-16 09:00:13', 13),
(182, 'Add New Media', ' upload edffa0e6fb38dfbe214ce95a6980cc3e.jpg as a new media.', '2017-05-16 09:09:40', 13),
(183, 'Add New Media', ' upload 44e7abef5e6ae595ea01173ea57e32a8.jpg as a new media.', '2017-05-16 09:24:30', 13),
(184, 'Add New Media', ' upload ddaba09246d2450127a64491b783ddb9.jpg as a new media.', '2017-05-16 09:29:12', 13),
(185, 'Delete Slider Image', ' delete one slider image in slider image section.', '2017-05-16 15:45:06', 1),
(186, 'Add New Media', ' upload f95833769cf5ee3340ba143eaa2df87a.jpg as a new media.', '2017-05-16 09:45:20', 1),
(187, 'Add New Slider Image', ' add new slider image in slider image section', '2017-05-16 15:45:22', 1),
(188, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 15:57:58', 1),
(189, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 15:59:05', 1),
(190, 'Add New Media', ' upload ef790c93148db7f6209a739fbef8cb04.jpg as a new media.', '2017-05-16 10:04:34', 14),
(191, 'Add New Media', ' upload b553f61c5bd0ecbba55738f5c5eba7fe.jpg as a new media.', '2017-05-16 10:14:37', 14),
(192, 'Add New Media', ' upload 9e5d71248fb783e08d8a87c0923eb0eb.jpg as a new media.', '2017-05-16 10:20:19', 14),
(193, 'Add New Media', ' upload f032876656e80708dd35bb467b2eb4a6.jpg as a new media.', '2017-05-16 10:21:48', 14),
(194, 'Add New Media', ' upload a6492aadb32f56a4f9a084c64094bf83.jpg as a new media.', '2017-05-16 10:28:53', 14),
(195, 'Add New Media', ' upload efa92be560968ce541ab2dc29f7af341.jpg as a new media.', '2017-05-16 10:53:14', 1),
(196, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 16:54:07', 1),
(197, 'Delete Slider Image', ' delete one slider image in slider image section.', '2017-05-16 17:00:12', 1),
(198, 'Add New Media', ' upload ce50959872ca495bb3a2f30d5f195597.jpg as a new media.', '2017-05-16 11:00:31', 1),
(199, 'Add New Slider Image', ' add new slider image in slider image section', '2017-05-16 17:00:40', 1),
(200, 'Add New Media', ' upload 3ee15c754eae634e4a4522feadca1efc.jpg as a new media.', '2017-05-16 11:07:26', 1),
(201, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 17:07:31', 1),
(202, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 17:08:22', 1),
(203, 'Add New Media', ' upload b129a1762a3a9b8e08d177f25b8d7d7e.jpg as a new media.', '2017-05-16 11:13:58', 1),
(204, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 17:14:02', 1),
(205, 'Add New Media', ' upload bcaf7032b93de287ebeb362c649fa486.JPG as a new media.', '2017-05-16 11:14:53', 1),
(206, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 17:15:11', 1),
(207, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 17:24:15', 1),
(208, 'Add New Media', ' upload 7a5a469af65d74815a598d7545c5fd5f.jpg as a new media.', '2017-05-16 11:26:46', 1),
(209, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 17:26:48', 1),
(210, 'Add New Media', ' upload 7550e477852c1587f66ae3636a974bb7.jpg as a new media.', '2017-05-16 11:29:24', 1),
(211, 'Edit Slider Image', ' edit slider image in slider image section.', '2017-05-16 17:29:28', 1),
(212, 'Add New Media', ' upload 648482aa5dea81ae924fd6ac1877b5aa.jpg as a new media.', '2017-05-16 11:31:34', 1),
(213, 'Edit Administrator', ' edit Adi Santos''s profile data.', '2017-05-16 17:31:40', 1),
(214, 'Add New Media', ' upload a7ce839b1501db10a02b7d9e272611c3.jpg as a new media.', '2017-05-16 11:32:56', 1),
(215, 'Edit Administrator', ' edit Adi Santos''s profile data.', '2017-05-16 17:33:04', 1),
(216, 'Add New Media', ' upload fd1ce4c0460ec9e8d18d6ffdc4799546.jpg as a new media.', '2017-05-16 14:17:15', 1),
(217, 'Edit Administrator', ' edit Adi Santos''s profile data.', '2017-05-16 20:17:19', 1),
(218, 'Add New Media', ' upload 3740321484bde8ff41db0736607e2b39.jpg as a new media.', '2017-05-17 05:48:12', 16),
(219, 'Add New Media', ' upload 1f734f7729aedf0974229c5a25affdac.jpg as a new media.', '2017-05-17 09:07:53', 17),
(220, 'Add New Media', ' upload df9501a11c224052ea51e9b76bfce666.jpg as a new media.', '2017-05-20 09:32:35', 1),
(221, 'Edit Administrator', ' edit Adi Santos''s profile data.', '2017-05-20 15:32:41', 1),
(222, 'Add New Media', ' upload 373e6b4907482f512d89bfbdb366aa86.jpg as a new media.', '2017-05-20 11:21:34', 19),
(223, 'Add New Media', ' upload 41fc06e7c3f964a9fa16800285b985bb.jpg as a new media.', '2017-05-24 11:04:15', 21),
(224, 'Add New Media', ' upload 8f865ea18caea9f61fff24830e8f396d.jpg as a new media.', '2017-05-24 12:49:28', 14),
(225, 'Add New Media', ' upload e37615527486ee274665e8eb3e8c8dc5.jpg as a new media.', '2017-05-24 12:50:31', 14);

-- --------------------------------------------------------

--
-- Table structure for table `cr_media`
--

CREATE TABLE `cr_media` (
  `cr_mediaID` int(11) NOT NULL,
  `cr_mediaName` varchar(255) NOT NULL,
  `cr_mediaDate` datetime NOT NULL,
  `cr_mediaTitle` varchar(255) NOT NULL,
  `cr_mediaDesc` text NOT NULL,
  `cr_adminID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_media`
--

INSERT INTO `cr_media` (`cr_mediaID`, `cr_mediaName`, `cr_mediaDate`, `cr_mediaTitle`, `cr_mediaDesc`, `cr_adminID`) VALUES
(1, 'b464af902f2737534729933d7ca63553.jpg', '2017-03-30 03:15:17', '', '', 1),
(2, '4a827a65f3bef1cefa784c6c262bddfd.jpg', '2017-03-30 09:19:51', '', '', 1),
(3, '9c54bce8ce81d0f1eb6ff8661c9db4b5.jpg', '2017-03-30 09:39:40', '', '', 1),
(4, 'c31c2345a82205a9e600401005d8b752.jpg', '2017-04-10 20:29:16', '', '', 9),
(5, '4b259757c8509ec04220283de5c23292.jpg', '2017-04-10 21:03:13', '', '', 9),
(6, '032783a27c56f44a0d820cc8e4015c68.jpg', '2017-04-10 21:12:21', '', '', 1),
(7, '11fbec840917da56d8ec893942923679.jpg', '2017-04-10 21:15:50', '', '', 9),
(8, '700902d8c06fefa5c4a784121859e9b5.jpg', '2017-04-10 21:23:27', '', '', 9),
(9, 'ba6cf450bda9605dbc51c60c8ece416a.jpg', '2017-04-10 21:32:04', '', '', 9),
(10, '54d859c89928da5fcad40229456c887b.jpg', '2017-04-10 21:40:37', '', '', 9),
(11, '306635c3d4e235f691d45fc23aec27a8.jpg', '2017-04-10 21:48:39', '', '', 9),
(12, '09d04054b833d65e7c07e4fee75ddb17.jpg', '2017-04-10 21:54:15', '', '', 9),
(13, '3ab3708ca4ddab7a77cfab4475218446.jpg', '2017-04-10 21:56:11', '', '', 9),
(14, '813fa15e03f3e2dd71e793c627f7c592.jpg', '2017-04-10 22:00:58', '', '', 9),
(15, 'aa97426f7e21485ecc59acdd11f974d3.jpg', '2017-04-11 08:18:05', '', '', 10),
(16, '66bec89f7d6ca425fdd59edc74d21014.jpg', '2017-04-11 08:47:54', '', '', 12),
(17, '728d46f3942d5d2aa88be4f889b924c7.jpg', '2017-04-11 08:51:33', '', '', 12),
(18, '565de082e23e5751443ada135ccd6f40.jpg', '2017-04-11 08:54:13', '', '', 12),
(19, '05ddc2c81d5426e84cb7f6562ecf7bf1.jpg', '2017-04-11 08:54:30', '', '', 12),
(20, '18aebcdbaba622ea6683c8774ea9a12c.jpg', '2017-04-11 08:57:38', '', '', 12),
(21, '573dc56d0e5e6a5ba645adb0b6f26129.jpg', '2017-04-11 09:08:19', '', '', 12),
(22, '49fa580bef95c0f6e8e166939c111966.jpg', '2017-04-11 09:25:45', '', '', 12),
(23, 'eb4e91dcfc0a1399ad99c940c1f650a4.jpg', '2017-04-14 07:33:19', '', '', 1),
(24, 'ded4f5d44f9b086dfdec63153a78f19f.jpg', '2017-04-14 07:40:03', '', '', 1),
(25, 'b368b79a2850756aecf805b30fca1920.jpg', '2017-04-14 07:49:01', '', '', 1),
(26, '35db64518ba7016f5f824a75c8df2b8c.jpg', '2017-04-15 06:52:40', '', '', 1),
(27, 'c6f1900f0a8d9975beed6948835071d9.jpg', '2017-04-15 06:54:39', '', '', 1),
(28, '6700b01d890331b890d9b54f93e1ad24.jpg', '2017-04-15 06:57:32', '', '', 1),
(29, '0c87a7b7355e24a827e1c68a7da504e9.jpg', '2017-04-15 07:02:34', '', '', 1),
(30, '340912857e778c9c2e633a4481069f29.jpg', '2017-04-15 07:03:30', '', '', 1),
(31, 'a61d1bab885f37db8f5e536dd79c1fb4.jpg', '2017-04-15 08:43:56', '', '', 1),
(32, 'e612ab764af12795f601040c671ec39e.jpg', '2017-04-15 08:51:06', '', '', 1),
(33, 'f70f93263c77b358fdc78500450321f7.jpg', '2017-04-15 08:52:59', '', '', 1),
(34, 'b85c00f2dfde40f432100f6484371adc.jpg', '2017-04-15 08:54:01', '', '', 1),
(35, '9bbe3349b7a58b7f39b684372e67a0bd.jpg', '2017-04-15 08:54:45', '', '', 1),
(36, '279cd9e3da1efc979ac70ce99f1ab976.jpg', '2017-04-15 09:06:34', '', '', 1),
(37, 'c7381cd1c4b708d29712312864815e44.jpg', '2017-04-15 09:57:27', '', '', 1),
(38, '10c515e372cce467c92e3eb620093cb4.jpg', '2017-04-15 10:10:15', '', '', 1),
(39, '81c6cc9507134aeefa9381c435d69ec1.jpg', '2017-04-15 10:11:57', '', '', 1),
(40, '8453d7f885c15a4edfc332c516bd8fe1.jpg', '2017-04-15 10:13:02', '', '', 1),
(41, 'fb1728faf9e55e12ecde9a6dc6e6e630.jpg', '2017-04-15 10:15:33', '', '', 1),
(42, '83830278cd6eb937f56fa75b57633e3c.jpg', '2017-04-15 10:18:09', '', '', 1),
(43, '62f87aa51b8758fcc8fe837ab33fb002.jpg', '2017-04-15 11:46:37', '', '', 15),
(44, '4619fc3e3528826cb41e6771d174549d.jpg', '2017-04-15 11:49:10', '', '', 15),
(45, '0f061c2aed1ba22b937b1001b85132ea.jpg', '2017-04-15 11:56:05', '', '', 15),
(46, '7eca01777350f7043df3a851d954a73a.jpg', '2017-04-15 12:42:24', '', '', 10),
(47, '8beb2bb1e9f4883babc2d6d145febe63.jpg', '2017-04-15 12:55:06', '', '', 10),
(48, 'aa4c020f4378ddf2f81446adfd97e137.jpg', '2017-04-15 12:57:02', '', '', 10),
(49, '0c8875818e0b01b682a1e6f4bdb5fea8.jpg', '2017-04-15 13:01:08', '', '', 10),
(50, 'c6944ce1f543138a21c216e066ec2e7f.jpg', '2017-04-15 13:15:36', '', '', 10),
(51, 'a64f7755c1f59dec6942555dce1e8fb4.jpg', '2017-04-15 13:26:10', '', '', 10),
(52, '3d57b7a32c2a1bfdf567037e324ef298.jpg', '2017-04-15 13:28:09', '', '', 10),
(53, 'ebf367bda501a7b0ff18c00e7f3535b9.jpg', '2017-04-15 13:29:19', '', '', 10),
(54, 'b397e9842f22f6e85583ea20f563f5db.jpg', '2017-04-16 18:56:38', '', '', 1),
(55, '31879c30378ff5fe5064913f892e6f8b.jpg', '2017-04-16 19:01:50', '', '', 1),
(56, '85dc6daca988978385ed2245839b236a.jpg', '2017-04-16 19:03:18', '', '', 1),
(57, 'e90b30c6f3eb4987fde79600dea4a3b0.jpg', '2017-04-16 19:09:42', '', '', 1),
(58, '8be07a5f025345478ca632d1d7c924fc.jpg', '2017-04-16 19:17:24', '', '', 1),
(59, 'd158e14d7aea1a7d7bc2f6a13bbed885.jpg', '2017-04-16 19:18:11', '', '', 1),
(60, 'bb8fd64138f31ea6e55a7f7935c4322e.jpg', '2017-04-16 19:28:05', '', '', 1),
(61, '2f0e509234da16af72f8b6f7b2fd3f12.jpg', '2017-04-16 21:48:08', '', '', 1),
(62, 'f0f18515261ebead8bf746d17ddbc613.jpg', '2017-04-16 21:51:06', '', '', 1),
(63, '7b4f4e5abbccbfa4c0374a302881aac2.jpg', '2017-04-16 21:52:38', '', '', 1),
(64, '4ded15b8cc41b0be532b531d4f85ffdf.jpg', '2017-04-16 21:54:02', '', '', 1),
(65, '46a9bdbb7294dd091e26bd40c0e45265.jpg', '2017-04-16 21:58:07', '', '', 2),
(66, '7d4de6f5ae06acdc3f25ed907efb00c7.jpg', '2017-04-16 22:00:14', '', '', 2),
(67, '8d584b5656218677423898764c4dd913.jpg', '2017-04-16 22:01:39', '', '', 2),
(68, '72c9e09daf792498e4aba989a3a32fbc.jpg', '2017-04-16 22:05:13', '', '', 3),
(69, 'dc37ef064e7308dc6623abe0651fa7d6.jpg', '2017-04-16 22:10:07', '', '', 4),
(70, 'b77f09341533e7260be439cc1c4daaa3.jpg', '2017-04-16 22:12:51', '', '', 1),
(71, '5acb59662d6abf5ee214afdc529605ff.jpg', '2017-04-18 17:38:00', '', '', 1),
(72, '7cce69b588d25a90c6f9fb156fbc683e.jpg', '2017-04-18 17:54:30', '', '', 1),
(73, '5658a12a45b0b150df6374cad2dbc0b3.jpg', '2017-04-18 18:14:38', '', '', 1),
(74, '9bfc05b168eb9942a6aa77e0778b7936.jpg', '2017-04-18 18:23:12', '', '', 1),
(75, '356688a8aa1ab8b4ade9606dd914abd5.jpg', '2017-04-25 05:32:32', '', '', 2),
(76, 'af485780f12e8b4e7f77fe686b28ee3e.jpg', '2017-05-02 11:29:06', '', '', 2),
(77, '2cf0cce0e17fd68d64a221aa5c9a9d02.jpg', '2017-05-10 05:43:01', '', '', 7),
(78, 'c4ec6d47f78205aac2dc575f6522e67c.jpg', '2017-05-10 05:52:37', '', '', 8),
(79, '4207b906fae5a9275aff92af47c8fec4.jpg', '2017-05-10 10:50:19', '', '', 1),
(80, '316fd6400b9ff33259109380e935dd70.jpg', '2017-05-14 11:44:24', '', '', 2),
(81, 'fed59bb8f6d8d65243ef1ed6fe3c08b5.jpg', '2017-05-14 11:45:21', '', '', 2),
(82, 'c9d3a2bc57e13d461e77180591c75762.jpg', '2017-05-14 13:28:39', '', '', 15),
(83, '0c07ba6b017e9479a9506551edea9350.jpg', '2017-05-14 13:37:36', '', '', 16),
(84, '5144d5296d35c3fa3a22987e6f65de35.jpg', '2017-05-14 13:46:45', '', '', 10),
(85, '43bbd4e07931b2785601390fa3ebb241.jpg', '2017-05-14 13:49:00', '', '', 10),
(86, '6e672a848985ec7ae5ef07763acb27ed.jpg', '2017-05-14 13:59:19', '', '', 11),
(87, 'f273f27714b810a99d1f020874ec36ca.jpg', '2017-05-14 13:59:51', '', '', 11),
(88, '42e804b78717fc394b1d84106c9256d7.jpg', '2017-05-14 14:03:17', '', '', 11),
(89, '7e2c00ab11a4d01a0e77defb64005fa7.jpg', '2017-05-14 14:08:43', '', '', 12),
(90, '423af05b3921b7de30b099e8c3c82e62.jpg', '2017-05-14 14:09:07', '', '', 12),
(91, 'df11d0a44cc60e8827b9771ef0b54bdb.jpg', '2017-05-16 06:10:15', '', '', 1),
(92, '3dd6addfbc8cf98575f931f168e07b84.jpg', '2017-05-16 06:14:02', '', '', 1),
(93, '0bfa1d7648d75b6d1c4bba74bad4c0c6.jpg', '2017-05-16 06:14:44', '', '', 1),
(94, 'aac396a1f1e0bfb8946070284be5a50e.jpg', '2017-05-16 06:23:45', '', '', 1),
(95, '7e6003f2087f5521ad8a0801c84e920f.jpg', '2017-05-16 08:23:04', '', '', 13),
(96, '9b2b5b4001f4bfb57dbf59d11c5f51f8.jpg', '2017-05-16 08:26:50', '', '', 13),
(97, 'ae125369d6001c8b42c472a115015792.jpg', '2017-05-16 08:36:00', '', '', 1),
(98, 'fa34a0807ff8f6dd879672a69f2a6395.jpg', '2017-05-16 08:41:52', '', '', 1),
(99, '7ddec448acd976a13d423e5f37626ba3.jpg', '2017-05-16 08:42:21', '', '', 1),
(100, '85473476ff515c792af24bcc7cea35d0.jpg', '2017-05-16 08:46:14', '', '', 13),
(101, '5e1170007fb95b4a76d2464d0d5674a0.jpg', '2017-05-16 08:48:08', '', '', 1),
(102, '612850d0d809bbee965a316ef48cac51.jpg', '2017-05-16 08:51:16', '', '', 13),
(103, '40f6de9cf610c6e1792b0041827fc917.jpg', '2017-05-16 08:52:58', '', '', 1),
(104, '9b0a86b82d1e21a431f3f3801c402571.jpg', '2017-05-16 08:54:21', '', '', 13),
(105, 'c081dded033d4f5773dde4e77f87610d.jpg', '2017-05-16 08:59:07', '', '', 13),
(106, 'befdc2f0ac215cece44dcf5382412d3b.jpg', '2017-05-16 09:00:13', '', '', 13),
(107, 'edffa0e6fb38dfbe214ce95a6980cc3e.jpg', '2017-05-16 09:09:40', '', '', 13),
(108, '44e7abef5e6ae595ea01173ea57e32a8.jpg', '2017-05-16 09:24:30', '', '', 13),
(109, 'ddaba09246d2450127a64491b783ddb9.jpg', '2017-05-16 09:29:12', '', '', 13),
(110, 'f95833769cf5ee3340ba143eaa2df87a.jpg', '2017-05-16 09:45:20', '', '', 1),
(111, 'ef790c93148db7f6209a739fbef8cb04.jpg', '2017-05-16 10:04:34', '', '', 14),
(112, 'b553f61c5bd0ecbba55738f5c5eba7fe.jpg', '2017-05-16 10:14:37', '', '', 14),
(113, '9e5d71248fb783e08d8a87c0923eb0eb.jpg', '2017-05-16 10:20:19', '', '', 14),
(114, 'f032876656e80708dd35bb467b2eb4a6.jpg', '2017-05-16 10:21:48', '', '', 14),
(115, 'a6492aadb32f56a4f9a084c64094bf83.jpg', '2017-05-16 10:28:53', '', '', 14),
(116, 'efa92be560968ce541ab2dc29f7af341.jpg', '2017-05-16 10:53:14', '', '', 1),
(117, 'ce50959872ca495bb3a2f30d5f195597.jpg', '2017-05-16 11:00:31', '', '', 1),
(118, '3ee15c754eae634e4a4522feadca1efc.jpg', '2017-05-16 11:07:26', '', '', 1),
(119, 'b129a1762a3a9b8e08d177f25b8d7d7e.jpg', '2017-05-16 11:13:58', '', '', 1),
(120, 'bcaf7032b93de287ebeb362c649fa486.JPG', '2017-05-16 11:14:53', '', '', 1),
(121, '7a5a469af65d74815a598d7545c5fd5f.jpg', '2017-05-16 11:26:46', '', '', 1),
(122, '7550e477852c1587f66ae3636a974bb7.jpg', '2017-05-16 11:29:24', '', '', 1),
(123, '648482aa5dea81ae924fd6ac1877b5aa.jpg', '2017-05-16 11:31:34', '', '', 1),
(124, 'a7ce839b1501db10a02b7d9e272611c3.jpg', '2017-05-16 11:32:56', '', '', 1),
(125, 'fd1ce4c0460ec9e8d18d6ffdc4799546.jpg', '2017-05-16 14:17:15', '', '', 1),
(126, '3740321484bde8ff41db0736607e2b39.jpg', '2017-05-17 05:48:12', '', '', 16),
(127, '1f734f7729aedf0974229c5a25affdac.jpg', '2017-05-17 09:07:53', '', '', 17),
(128, 'df9501a11c224052ea51e9b76bfce666.jpg', '2017-05-20 09:32:35', '', '', 1),
(129, '373e6b4907482f512d89bfbdb366aa86.jpg', '2017-05-20 11:21:34', '', '', 19),
(130, '41fc06e7c3f964a9fa16800285b985bb.jpg', '2017-05-24 11:04:15', '', '', 21),
(131, '8f865ea18caea9f61fff24830e8f396d.jpg', '2017-05-24 12:49:28', '', '', 14),
(132, 'e37615527486ee274665e8eb3e8c8dc5.jpg', '2017-05-24 12:50:31', '', '', 14);

-- --------------------------------------------------------

--
-- Table structure for table `cr_restaurants`
--

CREATE TABLE `cr_restaurants` (
  `cr_restaurantID` int(11) NOT NULL,
  `cr_restaurantName` varchar(200) NOT NULL,
  `cr_restaurantAddress` varchar(255) NOT NULL,
  `cr_restaurantLocation` varchar(100) NOT NULL,
  `cr_restaurantCode` varchar(50) NOT NULL,
  `cr_restaurantPhone` varchar(100) NOT NULL,
  `cr_restaurantEmail` varchar(100) NOT NULL,
  `cr_restaurantPassword` varchar(200) NOT NULL,
  `cr_restaurantWeb` varchar(200) NOT NULL,
  `cr_restaurantPhoto` varchar(255) NOT NULL,
  `cr_restaurantAbout` text NOT NULL,
  `cr_restaurantFb` varchar(200) NOT NULL,
  `cr_registered` datetime NOT NULL,
  `cr_token` varchar(200) NOT NULL,
  `cr_lastLogin` datetime NOT NULL,
  `cr_restaurantStatus` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_restaurants`
--

INSERT INTO `cr_restaurants` (`cr_restaurantID`, `cr_restaurantName`, `cr_restaurantAddress`, `cr_restaurantLocation`, `cr_restaurantCode`, `cr_restaurantPhone`, `cr_restaurantEmail`, `cr_restaurantPassword`, `cr_restaurantWeb`, `cr_restaurantPhoto`, `cr_restaurantAbout`, `cr_restaurantFb`, `cr_registered`, `cr_token`, `cr_lastLogin`, `cr_restaurantStatus`) VALUES
(1, 'Malaika Secret Garden', 'Jl. Danau Poso No. 68, Sanur, Bali', 'Denpasar', '80119', '0812 38341000', 'malaika1234@yahoo.com', '$2y$11$5f430c2d3f681a24d2431Os575gPqLc4bBqnTr33dwsc5GR61Cinm', 'malaika.co.id', '2f0e509234da16af72f8b6f7b2fd3f12.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae blandit nisl. Quisque ut risus mattis, finibus dolor posuere, blandit ligula. Nam nulla dui, molestie at velit at, imperdiet elementum est. Nulla vitae iaculis massa. Donec pellentesque sapien eget laoreet posuere. Morbi rutrum ornare est in eleifend. Nullam ac tortor enim.', 'facebook.com', '2017-04-16 21:46:16', '', '2017-04-18 19:51:39', 1),
(4, 'Cafe Moca', 'Jl. Raya Seminyak, Seminyak, Bali', 'Denpasar', '80119', '0361 731424', 'cafe_moka@yahoo.com', '$2y$11$808910e5ee14a3311617du5T6A/TIpulI4eaAyhwuW3sAbupBcvP6', 'asinan.co.id', 'dc37ef064e7308dc6623abe0651fa7d6.jpg', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae blandit nisl. Quisque ut risus mattis, finibus dolor posuere, blandit ligula. Nam nulla dui, molestie at velit at, imperdiet elementum est. Nulla vitae iaculis massa. Donec pellentesque sapien eget laoreet posuere. Morbi rutrum ornare est in eleifend. Nullam ac tortor enim.', '', '2017-04-16 22:08:46', '', '2017-04-16 22:08:46', 1),
(13, 'DA MARIA', 'Jl. Petitenget No. 170, Seminyak, Bali, 80113', 'Badung', '80133', '03619348523', 'damariabali@gmail.com', '$2y$11$16f40666f1509dfe5879fupyiX5aJzEGPP0CPL04YhtI8GofLdLle', 'damariabali.com', 'edffa0e6fb38dfbe214ce95a6980cc3e.jpg', '', 'damariabali', '2017-05-16 08:21:55', '', '2017-05-17 05:52:02', 1),
(14, 'Potato Head Restaurant', 'Seminyak, Jl. Petitenget No.51B, Kerobokan Kelod, Kuta Utara, Kabupaten Badung, Bali 80361', 'Badung', '80361', '(0361) 4737979', 'potatohead@gmail.com', '$2y$11$c28c8256467d13a5ed7b1O3G7cfhNLpYcM5iI3DFLR9Lifd7q4Gt6', 'www.ptthead.com/bali', 'e37615527486ee274665e8eb3e8c8dc5.jpg', '', 'pttheadbali', '2017-05-16 10:03:46', '', '2017-05-24 12:48:38', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cr_restaurants_category`
--

CREATE TABLE `cr_restaurants_category` (
  `ID` int(11) NOT NULL,
  `cr_image` varchar(255) NOT NULL,
  `cr_name` varchar(200) NOT NULL,
  `cr_description` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_restaurants_category`
--

INSERT INTO `cr_restaurants_category` (`ID`, `cr_image`, `cr_name`, `cr_description`) VALUES
(1, '4a827a65f3bef1cefa784c6c262bddfd.jpg', 'Dine-Out', 'Lorem ipsum Lorem ipsum Lorem ipsum Lorem ipsum '),
(2, 'b464af902f2737534729933d7ca63553.jpg', 'Drinks & Nightlife', 'lorem ipsum'),
(3, '9c54bce8ce81d0f1eb6ff8661c9db4b5.jpg', 'Delivery', 'Delivery Delivery Delivery');

-- --------------------------------------------------------

--
-- Table structure for table `cr_restaurants_cuisines`
--

CREATE TABLE `cr_restaurants_cuisines` (
  `ID` int(11) NOT NULL,
  `cr_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_restaurants_cuisines`
--

INSERT INTO `cr_restaurants_cuisines` (`ID`, `cr_name`) VALUES
(1, 'Balinese'),
(2, 'American'),
(3, 'Asian'),
(4, 'Betawi');

-- --------------------------------------------------------

--
-- Table structure for table `cr_restaurants_feature`
--

CREATE TABLE `cr_restaurants_feature` (
  `ID` int(11) NOT NULL,
  `cr_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_restaurants_feature`
--

INSERT INTO `cr_restaurants_feature` (`ID`, `cr_name`) VALUES
(1, 'Breakfast'),
(2, 'Dinner'),
(3, 'Delivery'),
(4, 'Lunch');

-- --------------------------------------------------------

--
-- Table structure for table `cr_restaurants_reviews`
--

CREATE TABLE `cr_restaurants_reviews` (
  `ID` int(11) NOT NULL,
  `cr_foodiesID` int(11) NOT NULL,
  `cr_foodiesName` varchar(200) NOT NULL,
  `cr_foodiesmail` varchar(200) NOT NULL,
  `cr_subject` varchar(200) NOT NULL,
  `cr_tgl` datetime NOT NULL,
  `cr_text` text NOT NULL,
  `cr_status` int(11) NOT NULL,
  `cr_star` int(11) NOT NULL,
  `cr_menuID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_restaurants_reviews`
--

INSERT INTO `cr_restaurants_reviews` (`ID`, `cr_foodiesID`, `cr_foodiesName`, `cr_foodiesmail`, `cr_subject`, `cr_tgl`, `cr_text`, `cr_status`, `cr_star`, `cr_menuID`) VALUES
(1, 1, 'Susan', 'suan1234@yahoo.com', 'Test aja ', '2017-04-16 22:13:52', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae blandit nisl. Quisque ut risus mattis, finibus dolor posuere, blandit ligula. Nam nulla dui, molestie at velit at, imperdiet elementum est. Nulla vitae iaculis massa. Donec pellentesque sapien eget laoreet posuere. Morbi rutrum ornare est in eleifend. Nullam ac tortor enim.', 0, 4, 4),
(2, 1, 'Susan', 'suan1234@yahoo.com', 'Makanan Enak', '2017-04-16 22:17:29', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae blandit nisl. Quisque ut risus mattis, finibus dolor posuere, blandit ligula. Nam nulla dui, molestie at velit at, imperdiet elementum est. Nulla vitae iaculis massa. Donec pellentesque sapien eget laoreet posuere. Morbi rutrum ornare est in eleifend. Nullam ac tortor enim.', 0, 1, 5),
(3, 1, 'Susan', 'suan1234@yahoo.com', 'Test aja ', '2017-04-16 22:33:01', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae blandit nisl. Quisque ut risus mattis, finibus dolor posuere, blandit ligula. Nam nulla dui, molestie at velit at, imperdiet el', 0, 4, 3),
(4, 3, 'Sidi', 'sidi@gmail.com', 'Nice Food ', '2017-05-09 11:29:04', 'Im loving it', 0, 5, 3),
(5, 3, 'Sidi', 'sidi@gmail.com', 'FUN', '2017-05-09 11:32:41', 'yummy ', 0, 4, 2),
(6, 4, 'Agus', 'agus@mail.com', '1', '2017-05-09 12:20:26', 'afasasfas', 0, 5, 2),
(7, 5, 'Ester', 'ester@mial.com', 'deliciouse', '2017-05-09 12:21:51', ':)', 0, 5, 2),
(8, 6, 'Arthure', 'arthure@mail.com', 'I love fish', '2017-05-09 12:27:05', 'yummy tummy', 0, 4, 2),
(9, 8, 'Adisantos', 'adisantos@yahoo.com', 'Nice Food', '2017-05-10 05:54:15', 'Delicious food and good taste', 0, 4, 5),
(10, 9, 'Adisantos', 'santos@gmail.com', 'Nice Food', '2017-05-10 05:59:57', 'delicious and good taste', 0, 4, 4),
(11, 12, 'Deddyguterres', 'santos@gmail.com', 'Good Pizza', '2017-05-10 06:32:14', 'Delicious ', 0, 4, 1),
(12, 14, 'Zefu', 'zefi@mail.com', 'Lol', '2017-05-10 13:17:34', 'Lololil', 0, 5, 4),
(13, 16, 'Batman', 'bat@gmail.com', 'nice pizza', '2017-05-14 13:39:31', 'great taste', 0, 4, 1),
(14, 16, 'Batman', 'bat@gmail.com', 'Good Pizza', '2017-05-16 11:17:47', 'Delicious', 0, 4, 12),
(15, 16, 'Batman', 'bat@gmail.com', 'Nice Drink', '2017-05-17 05:49:52', 'I Love it', 0, 4, 14),
(16, 17, 'Zefibulkiah', 'zefi@gmail.com', 'Nice Food', '2017-05-17 09:08:54', 'deliciouse', 0, 4, 13),
(17, 19, 'Adisantos', 'adisantos@gmail.com', 'Fresh Food', '2017-05-20 10:48:37', 'I Love it', 0, 4, 17),
(18, 21, 'Zefibulkiah', 'zefi@gmail.com', 'nice pizza', '2017-05-24 11:05:16', 'Love it', 0, 4, 12);

-- --------------------------------------------------------

--
-- Table structure for table `cr_restaurants_type`
--

CREATE TABLE `cr_restaurants_type` (
  `ID` int(11) NOT NULL,
  `cr_name` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_restaurants_type`
--

INSERT INTO `cr_restaurants_type` (`ID`, `cr_name`) VALUES
(1, 'Bars'),
(2, 'Quick Bites'),
(3, 'Casual Dining');

-- --------------------------------------------------------

--
-- Table structure for table `cr_restaurant_menu`
--

CREATE TABLE `cr_restaurant_menu` (
  `cr_menuID` int(11) NOT NULL,
  `cr_menuName` varchar(200) NOT NULL,
  `cr_menuCuisine` varchar(200) NOT NULL,
  `cr_menuPrice` varchar(100) NOT NULL,
  `cr_menuDesc` text NOT NULL,
  `cr_menuPhoto` varchar(200) NOT NULL,
  `cr_restaurantID` int(11) NOT NULL,
  `cr_registered` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_restaurant_menu`
--

INSERT INTO `cr_restaurant_menu` (`cr_menuID`, `cr_menuName`, `cr_menuCuisine`, `cr_menuPrice`, `cr_menuDesc`, `cr_menuPhoto`, `cr_restaurantID`, `cr_registered`) VALUES
(1, 'Pizza Italian', 'Eropa', 'Rp. 90.000', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae blandit nisl. Quisque ut risus mattis, finibus dolor posuere, blandit ligula. Nam nulla dui, molestie at velit at', 'f0f18515261ebead8bf746d17ddbc613.jpg', 1, '2017-04-16 21:51:10'),
(3, 'Burger King', 'American', 'Rp. 90.000', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Aenean vitae blandit nisl. Quisque ut risus mattis, finibus dolor posuere, blandit ligula. Nam nulla dui, molestie at velit at', '4ded15b8cc41b0be532b531d4f85ffdf.jpg', 1, '2017-04-16 21:54:06'),
(12, 'Pizza Melanzane', 'Italian Fusion', 'Rp. 110000', 'grilled eggplant – chilli – fior di latte – ricotta salata', '9b0a86b82d1e21a431f3f3801c402571.jpg', 13, '2017-05-16 08:54:23'),
(13, 'Spaghetti Bolognese', 'Italian', 'Rp. 60,000', 'Spaghetti Bolognese with pasta', 'c081dded033d4f5773dde4e77f87610d.jpg', 13, '2017-05-16 08:59:10'),
(14, 'SICILIAN MARGARITA', 'Sicilian Italian', 'Rp. 130000', 'Campari – tequila – cinnamon – blood orange – lime', '44e7abef5e6ae595ea01173ea57e32a8.jpg', 13, '2017-05-16 09:24:32'),
(15, 'DA MARIA X DOLPHIN', 'Italian Gin', 'Rp. 90000', 'Tanqueray gin – Mancino secco – orange bitters – olive – lemon', 'ddaba09246d2450127a64491b783ddb9.jpg', 13, '2017-05-16 09:29:24'),
(17, 'Tuna Nicoise', 'America latin', 'Rp. 145000', 'Green beans, egg, potato, cherry tomato, olives, lettuce,\r\nanchovy & lemon dressing', 'f032876656e80708dd35bb467b2eb4a6.jpg', 14, '2017-05-16 10:21:49'),
(18, 'ROSELLA MARGARITA', 'Italian Fusion', 'Rp. 130000', 'Rosella tequila, orange curaçao, bar-made rosella and vanilla syrup and citrus. Shaken and served with a rosella sugar-salt rim', 'a6492aadb32f56a4f9a084c64094bf83.jpg', 14, '2017-05-16 10:28:56'),
(19, 'Ayam Betutu', 'Balinese Food', 'Rp. 60000', '', '8f865ea18caea9f61fff24830e8f396d.jpg', 14, '2017-05-24 12:49:49');

-- --------------------------------------------------------

--
-- Table structure for table `cr_setting`
--

CREATE TABLE `cr_setting` (
  `cr_settingID` int(11) NOT NULL,
  `cr_settingName` varchar(100) NOT NULL,
  `cr_settingValue` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cr_setting`
--

INSERT INTO `cr_setting` (`cr_settingID`, `cr_settingName`, `cr_settingValue`) VALUES
(1, 'sitename', 'Food Review'),
(2, 'siteurl', 'http://'),
(3, 'foldername', 'food-review'),
(4, 'tagline', ''),
(5, 'template', 'foodreview'),
(6, 'email', 'youremail@mail.com'),
(7, 'phone', '081123456789'),
(8, 'secondaryfooter', ''),
(9, 'metakeywords', ''),
(10, 'metadescription', ''),
(11, 'contactheader', '1,1,1'),
(12, 'address', ''),
(13, 'websitelogo', ''),
(14, 'colorscheme', 'green'),
(15, 'homepagestyle', 'image-slider::'),
(16, 'favicon', ''),
(17, 'timezone', '(UTC+08:00) Asia/Makassar'),
(18, 'recaptchasitekey', ''),
(19, 'recaptchasecret', ''),
(20, 'customprimary', ''),
(21, 'customsecondary', ''),
(22, 'googlemapapi', ''),
(23, 'googleanalyticscode', ''),
(24, 'layoutmode', ''),
(25, 'backgroundtemplate', ''),
(26, 'dateformat', 'F d, Y'),
(27, 'timeformat', 'g:i a'),
(28, 'comingsoon', 'disable'),
(29, 'datetimemaintenance', ''),
(30, 'backgroundrepeat', ''),
(31, 'backgroundposition', ''),
(32, 'backgroundattachment', ''),
(33, 'backgroundsize', ''),
(34, 'homepagelink', 'show'),
(35, 'backgroundlogin', ''),
(36, 'footer-column4', 'disable'),
(37, 'invoicelogo', ''),
(38, 'quotesinpage', ''),
(39, 'servicestitle', 'Services'),
(40, 'servicesinpage', ''),
(41, 'clientspartnersinpage', ''),
(42, 'quotestitle', ''),
(49, 'userplan', 'probasic'),
(44, 'totalpage', '999999'),
(45, 'instafeeduserid', ''),
(46, 'instafeedaccesstoken', ''),
(47, 'developermode', 'off'),
(48, 'clientstitle', 'Our Clients'),
(50, 'facebook', 'facebook.com'),
(51, 'twitter', 'twitter.com'),
(52, 'googleplus', 'google.com');

-- --------------------------------------------------------

--
-- Table structure for table `cr_slider`
--

CREATE TABLE `cr_slider` (
  `cr_sliderID` int(11) NOT NULL,
  `cr_sliderImage` varchar(255) NOT NULL,
  `cr_sliderCaption` varchar(100) NOT NULL,
  `cr_sliderDesc` text NOT NULL,
  `cr_sliderButtontext` varchar(50) NOT NULL,
  `cr_sliderButtonlink` varchar(50) NOT NULL,
  `cr_sliderTextposition` varchar(6) NOT NULL,
  `cr_adminID` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `cr_slider`
--

INSERT INTO `cr_slider` (`cr_sliderID`, `cr_sliderImage`, `cr_sliderCaption`, `cr_sliderDesc`, `cr_sliderButtontext`, `cr_sliderButtonlink`, `cr_sliderTextposition`, `cr_adminID`) VALUES
(4, '7550e477852c1587f66ae3636a974bb7.jpg', 'WELCOME TO LA PLANCHA BALI', '', '', '', 'center', 1),
(8, 'f95833769cf5ee3340ba143eaa2df87a.jpg', 'WELCOME TO IKAN BAKAR CIANJUR RENON', '', '', '', 'center', 1),
(9, '3ee15c754eae634e4a4522feadca1efc.jpg', '<br>WELCOME TO LA LAGUNA BALI<br>', '', '', '', 'center', 1);

-- --------------------------------------------------------

--
-- Table structure for table `cr_visitor`
--

CREATE TABLE `cr_visitor` (
  `cr_visitorID` int(11) NOT NULL,
  `cr_visitorIP` varchar(50) NOT NULL,
  `cr_visitorBrowser` varchar(100) NOT NULL,
  `cr_visitorPlatform` varchar(100) NOT NULL,
  `cr_visitorDate` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `cr_visitor`
--

INSERT INTO `cr_visitor` (`cr_visitorID`, `cr_visitorIP`, `cr_visitorBrowser`, `cr_visitorPlatform`, `cr_visitorDate`) VALUES
(1, '::1', 'Google Chrome', 'Windows', '2017-03-15 14:08:46'),
(2, '172.16.205.231', 'Google Chrome', 'Linux', '2017-05-10 19:14:01');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `cr_admin`
--
ALTER TABLE `cr_admin`
  ADD PRIMARY KEY (`cr_adminID`);

--
-- Indexes for table `cr_article`
--
ALTER TABLE `cr_article`
  ADD PRIMARY KEY (`cr_ID`);

--
-- Indexes for table `cr_foodies`
--
ALTER TABLE `cr_foodies`
  ADD PRIMARY KEY (`cr_loginID`);

--
-- Indexes for table `cr_history`
--
ALTER TABLE `cr_history`
  ADD PRIMARY KEY (`cr_historyID`);

--
-- Indexes for table `cr_media`
--
ALTER TABLE `cr_media`
  ADD PRIMARY KEY (`cr_mediaID`);

--
-- Indexes for table `cr_restaurants`
--
ALTER TABLE `cr_restaurants`
  ADD PRIMARY KEY (`cr_restaurantID`);

--
-- Indexes for table `cr_restaurants_category`
--
ALTER TABLE `cr_restaurants_category`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cr_restaurants_cuisines`
--
ALTER TABLE `cr_restaurants_cuisines`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cr_restaurants_feature`
--
ALTER TABLE `cr_restaurants_feature`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cr_restaurants_reviews`
--
ALTER TABLE `cr_restaurants_reviews`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cr_restaurants_type`
--
ALTER TABLE `cr_restaurants_type`
  ADD PRIMARY KEY (`ID`);

--
-- Indexes for table `cr_restaurant_menu`
--
ALTER TABLE `cr_restaurant_menu`
  ADD PRIMARY KEY (`cr_menuID`);

--
-- Indexes for table `cr_setting`
--
ALTER TABLE `cr_setting`
  ADD PRIMARY KEY (`cr_settingID`);

--
-- Indexes for table `cr_slider`
--
ALTER TABLE `cr_slider`
  ADD PRIMARY KEY (`cr_sliderID`);

--
-- Indexes for table `cr_visitor`
--
ALTER TABLE `cr_visitor`
  ADD PRIMARY KEY (`cr_visitorID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `cr_admin`
--
ALTER TABLE `cr_admin`
  MODIFY `cr_adminID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cr_article`
--
ALTER TABLE `cr_article`
  MODIFY `cr_ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT for table `cr_foodies`
--
ALTER TABLE `cr_foodies`
  MODIFY `cr_loginID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
--
-- AUTO_INCREMENT for table `cr_history`
--
ALTER TABLE `cr_history`
  MODIFY `cr_historyID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=226;
--
-- AUTO_INCREMENT for table `cr_media`
--
ALTER TABLE `cr_media`
  MODIFY `cr_mediaID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=133;
--
-- AUTO_INCREMENT for table `cr_restaurants`
--
ALTER TABLE `cr_restaurants`
  MODIFY `cr_restaurantID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;
--
-- AUTO_INCREMENT for table `cr_restaurants_category`
--
ALTER TABLE `cr_restaurants_category`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cr_restaurants_cuisines`
--
ALTER TABLE `cr_restaurants_cuisines`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cr_restaurants_feature`
--
ALTER TABLE `cr_restaurants_feature`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT for table `cr_restaurants_reviews`
--
ALTER TABLE `cr_restaurants_reviews`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;
--
-- AUTO_INCREMENT for table `cr_restaurants_type`
--
ALTER TABLE `cr_restaurants_type`
  MODIFY `ID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT for table `cr_restaurant_menu`
--
ALTER TABLE `cr_restaurant_menu`
  MODIFY `cr_menuID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;
--
-- AUTO_INCREMENT for table `cr_setting`
--
ALTER TABLE `cr_setting`
  MODIFY `cr_settingID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=53;
--
-- AUTO_INCREMENT for table `cr_slider`
--
ALTER TABLE `cr_slider`
  MODIFY `cr_sliderID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT for table `cr_visitor`
--
ALTER TABLE `cr_visitor`
  MODIFY `cr_visitorID` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
